# ================================================
# 이단·사이비 피해 상담 챗봇 — GitHub Pages 자동 배포 (Windows)
# ================================================

$RepoName = "counseling-bot"
$Branch = "main"

Write-Host ""
Write-Host "╔══════════════════════════════════════════╗" -ForegroundColor Blue
Write-Host "║   마음 상담 챗봇 — GitHub Pages 배포    ║" -ForegroundColor Blue
Write-Host "╚══════════════════════════════════════════╝" -ForegroundColor Blue
Write-Host ""

# ── 1. gh CLI 확인 ──
if (-not (Get-Command gh -ErrorAction SilentlyContinue)) {
    Write-Host "✗ GitHub CLI가 설치되어 있지 않아요." -ForegroundColor Red
    Write-Host ""
    Write-Host "설치: winget install GitHub.cli" -ForegroundColor Yellow
    Write-Host "설치 후 이 스크립트를 다시 실행해 주세요."
    exit 1
}

# ── 2. 로그인 확인 ──
$authStatus = gh auth status 2>&1
if ($LASTEXITCODE -ne 0) {
    Write-Host "▶ GitHub 로그인이 필요해요." -ForegroundColor Yellow
    gh auth login
}

$GhUser = gh api user --jq '.login'
Write-Host "✓ 로그인 확인: @$GhUser" -ForegroundColor Green
Write-Host ""

# ── 3. Repository 생성 ──
Write-Host "▶ Repository 생성 중..." -ForegroundColor Blue
$repoCheck = gh repo view "$GhUser/$RepoName" 2>&1
if ($LASTEXITCODE -eq 0) {
    Write-Host "  이미 존재하는 Repository예요. 파일만 업데이트할게요." -ForegroundColor Yellow
} else {
    gh repo create $RepoName --public --description "이단·사이비 피해 상담 챗봇" --clone=false
    Write-Host "✓ Repository 생성 완료" -ForegroundColor Green
}

# ── 4. Git Push ──
Write-Host ""
Write-Host "▶ 파일 업로드 중..." -ForegroundColor Blue

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ScriptDir

if (-not (Test-Path ".git")) {
    git init
    git checkout -b $Branch
}

git config user.email "$GhUser@users.noreply.github.com" 2>$null
git config user.name $GhUser 2>$null

git remote remove origin 2>$null
git remote add origin "https://github.com/$GhUser/$RepoName.git"

git add index.html
git commit -m "🕊️ 마음 상담 챗봇 배포" --allow-empty

git push -u origin $Branch --force
Write-Host "✓ 파일 업로드 완료" -ForegroundColor Green

# ── 5. GitHub Pages 활성화 ──
Write-Host ""
Write-Host "▶ GitHub Pages 활성화 중..." -ForegroundColor Blue
Start-Sleep -Seconds 2

gh api --method POST -H "Accept: application/vnd.github+json" `
    "/repos/$GhUser/$RepoName/pages" `
    -f 'source={"branch":"main","path":"/"}' 2>$null

Write-Host "✓ GitHub Pages 활성화 완료" -ForegroundColor Green

# ── 6. 완료 ──
$SiteUrl = "https://$GhUser.github.io/$RepoName"
Write-Host ""
Write-Host "╔══════════════════════════════════════════════════╗" -ForegroundColor Green
Write-Host "║              🎉 배포 완료!                        ║" -ForegroundColor Green
Write-Host "╠══════════════════════════════════════════════════╣" -ForegroundColor Green
Write-Host "║  🌐 사이트 주소:                                   ║" -ForegroundColor Green
Write-Host "║     $SiteUrl" -ForegroundColor Cyan
Write-Host "║                                                    ║" -ForegroundColor Green
Write-Host "║  ⏳ 첫 배포는 1~3분 후 접속 가능해요.             ║" -ForegroundColor Green
Write-Host "╚══════════════════════════════════════════════════╝" -ForegroundColor Green
Write-Host ""
