# 🕊️ 마음 상담 챗봇 — GitHub Pages 배포 가이드

---

## ✅ 준비물 (딱 2가지)

1. **GitHub 계정** — [github.com](https://github.com) (무료)
2. **GitHub CLI** — 아래 설치 방법 참고

---

## 1단계 — GitHub CLI 설치

| 운영체제 | 설치 명령어 |
|---------|------------|
| Mac     | `brew install gh` |
| Windows | `winget install GitHub.cli` |
| Ubuntu  | `sudo apt install gh` |

설치 확인: 터미널에서 `gh --version` 입력

---

## 2단계 — 이 폴더를 PC에 저장

다운로드받은 폴더 안에 이 파일들이 있어야 해요:
```
📁 github-pages-deploy/
   ├── index.html      ← 챗봇 파일
   ├── deploy.sh       ← Mac/Linux 실행 스크립트
   ├── deploy.ps1      ← Windows 실행 스크립트
   └── README.md       ← 이 가이드
```

---

## 3단계 — 스크립트 실행

### Mac / Linux
```bash
cd github-pages-deploy
chmod +x deploy.sh
./deploy.sh
```

### Windows (PowerShell)
```powershell
cd github-pages-deploy
.\deploy.ps1
```

> **처음 실행 시** GitHub 로그인 화면이 나와요.  
> `Login with a web browser` 선택 → 브라우저에서 승인 → 완료

---

## 4단계 — 완료!

스크립트가 끝나면 주소가 나와요:

```
🌐 https://내아이디.github.io/counseling-bot
```

⏳ **첫 배포는 1~3분** 후 접속 가능해요.

---

## ⚠️ 중요: API 키 설정

이 챗봇은 Anthropic API를 사용해요.  
GitHub Pages에 올린 버전은 **API 키 없이는 상담 응답이 작동하지 않아요**.

### 무료로 API 키 받는 방법
1. [console.anthropic.com](https://console.anthropic.com) 접속
2. 회원가입 → API Keys → Create Key
3. `index.html` 파일에서 아래 부분을 수정:

```javascript
// index.html 내부 callClaude 함수에 추가
headers: {
  'Content-Type': 'application/json',
  'x-api-key': '여기에-API-키-입력',   ← 이 줄 추가
  'anthropic-version': '2023-06-01'
},
```

> ⚠️ API 키를 HTML에 직접 넣으면 누구나 볼 수 있어요.  
> 개인 용도나 비공개 사용에만 권장해요.  
> 공개 서비스라면 백엔드 서버(Netlify Functions 등)를 통해 키를 숨기세요.

---

## 🔄 챗봇 내용 수정 후 재배포

```bash
# 파일 수정 후
./deploy.sh   # 다시 실행하면 자동 업데이트
```

---

## 🆘 문제가 생겼을 때

| 증상 | 해결 |
|------|------|
| `gh: command not found` | GitHub CLI 설치 안 됨 → 1단계 다시 |
| 사이트가 안 열림 | 1~3분 기다린 후 새로고침 |
| 404 오류 | Repository → Settings → Pages 확인 |
| API 오류 | index.html에 API 키 추가 확인 |

---

*위기 상황 시: 경찰청 112 / 정신건강상담전화 109*
