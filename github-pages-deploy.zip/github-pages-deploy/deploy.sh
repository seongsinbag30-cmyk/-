#!/bin/bash
# ================================================
# 이단·사이비 피해 상담 챗봇 — GitHub Pages 자동 배포
# ================================================
set -e

REPO_NAME="counseling-bot"
BRANCH="main"

# ── 색상 출력 ──
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo ""
echo -e "${BLUE}╔══════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║   마음 상담 챗봇 — GitHub Pages 배포    ║${NC}"
echo -e "${BLUE}╚══════════════════════════════════════════╝${NC}"
echo ""

# ── 1. gh CLI 확인 ──
if ! command -v gh &>/dev/null; then
  echo -e "${RED}✗ GitHub CLI(gh)가 설치되어 있지 않아요.${NC}"
  echo ""
  echo "설치 방법:"
  echo "  Mac:   brew install gh"
  echo "  Win:   winget install GitHub.cli"
  echo "  Linux: https://github.com/cli/cli#installation"
  exit 1
fi

# ── 2. 로그인 확인 ──
if ! gh auth status &>/dev/null; then
  echo -e "${YELLOW}▶ GitHub 로그인이 필요해요.${NC}"
  echo ""
  gh auth login
fi

GH_USER=$(gh api user --jq '.login')
echo -e "${GREEN}✓ 로그인 확인: @${GH_USER}${NC}"
echo ""

# ── 3. Repository 생성 ──
echo -e "${BLUE}▶ Repository 생성 중...${NC}"
if gh repo view "${GH_USER}/${REPO_NAME}" &>/dev/null; then
  echo -e "${YELLOW}  이미 존재하는 Repository예요. 파일만 업데이트할게요.${NC}"
else
  gh repo create "${REPO_NAME}" \
    --public \
    --description "이단·사이비 피해 상담 챗봇" \
    --clone=false
  echo -e "${GREEN}✓ Repository 생성 완료${NC}"
fi

# ── 4. Git 초기화 및 Push ──
echo ""
echo -e "${BLUE}▶ 파일 업로드 중...${NC}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

if [ ! -d ".git" ]; then
  git init
  git checkout -b ${BRANCH}
fi

git config user.email "${GH_USER}@users.noreply.github.com" 2>/dev/null || true
git config user.name "${GH_USER}" 2>/dev/null || true

# remote 설정
git remote remove origin 2>/dev/null || true
git remote add origin "https://github.com/${GH_USER}/${REPO_NAME}.git"

git add index.html
git commit -m "🕊️ 마음 상담 챗봇 배포" --allow-empty

git push -u origin ${BRANCH} --force
echo -e "${GREEN}✓ 파일 업로드 완료${NC}"

# ── 5. GitHub Pages 활성화 ──
echo ""
echo -e "${BLUE}▶ GitHub Pages 활성화 중...${NC}"
sleep 2

gh api \
  --method POST \
  -H "Accept: application/vnd.github+json" \
  "/repos/${GH_USER}/${REPO_NAME}/pages" \
  -f source='{"branch":"main","path":"/"}' \
  2>/dev/null || \
gh api \
  --method PUT \
  -H "Accept: application/vnd.github+json" \
  "/repos/${GH_USER}/${REPO_NAME}/pages" \
  -f source='{"branch":"main","path":"/"}' \
  2>/dev/null || true

echo -e "${GREEN}✓ GitHub Pages 활성화 완료${NC}"

# ── 6. 완료 ──
SITE_URL="https://${GH_USER}.github.io/${REPO_NAME}"
echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║                   🎉 배포 완료!                      ║${NC}"
echo -e "${GREEN}╠══════════════════════════════════════════════════════╣${NC}"
echo -e "${GREEN}║  🌐 사이트 주소:                                      ║${NC}"
echo -e "${GREEN}║     ${SITE_URL}${NC}"
echo -e "${GREEN}║                                                        ║${NC}"
echo -e "${GREEN}║  ⏳ 첫 배포는 1~3분 후 접속 가능해요.                 ║${NC}"
echo -e "${GREEN}║  📋 Repository: github.com/${GH_USER}/${REPO_NAME}   ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════════════╝${NC}"
echo ""
